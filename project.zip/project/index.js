const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const csv = require('csv-parser');
const Web3 = require('web3');
const  Wallet = require('ethereumjs-wallet').default
const Tx = require('ethereumjs-tx').Transaction;


const app = express();
const web3 = new Web3('https://rpc2.sepolia.org');






const contractABI = require('./contractABI.json');


const contractAddress = '0x89834979352CE98885D04eE5614C707DB35545B1';
const contractInstance = new web3.eth.Contract(contractABI, contractAddress);


const privateKey = 'ae44534475491acd6f5b5473e8cfcec9d62d14b9539be51716f15febcf6407aa';
const wallet = Wallet.fromPrivateKey(Buffer.from(privateKey, 'hex'));


app.use(bodyParser.json());


app.use(express.json());





async function sendTransactions(filePath) {
    const data = fs.readFileSync(filePath, 'utf8');
    const lines = data.split('\n');
  
    for (let i = 0; i < lines.length; i++) {
      try {
        const line = lines[i];
        const account = web3.eth.accounts.privateKeyToAccount(privateKey);
  
        const data = contractInstance.methods.storeString(line).encodeABI();
  
        const gasPrice = await web3.eth.getGasPrice();
        const nonce = await web3.eth.getTransactionCount(account.address);
  
        const txObject = {
          nonce: nonce,
          gasPrice: gasPrice,
          gasLimit: web3.utils.toHex(300000),
          to: contractAddress,
          data: data,
         };
  
        const signedTx = await web3.eth.accounts.signTransaction(txObject, privateKey);
  
        const receipt = await web3.eth.sendSignedTransaction(signedTx.rawTransaction);
        console.log('Transaction Hash:', receipt.transactionHash);
      } catch (error) {
        console.error(error);
      }
    }
  }

  app.post('/test', (req, res) => {
    const { filePath } = req.body;
  
    sendTransactions(filePath)
      .then(() => {
        res.json({ message: 'Transactions envoyées avec succés.' });
      })
      .catch((error) => {
        console.error(error);
        res.status(500).json({ error: 'Echec de la transaction.' });
      });
  });


const port = 3000; 
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
